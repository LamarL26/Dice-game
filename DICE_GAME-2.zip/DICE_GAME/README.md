# WELCOME TO TURPLE OUT! 
A very lovely 2 player dice game. 

## First, you will be asked how many points you'd like to play till! 
Please input a **numerical value** between or equal to 10 and 500. 

## RULES! 
1. Player 1 rolls 3,  6 sided die
2. if all the rolled dice end up being the same number, the player earns zero points and tuples out
3. if two of the dice roll to be the same value, they can not be re-rolled and remain those numbers 
4. Player 1 continues to roll the final dice as often as they like, attempting to get a high number that is NOT the same as the previous 2 die
5. If the player is satisifed with their roll, they earn all the points
6. If the player rolls the same number as the previous two dice, they tuple out and earn 0 points 
7. Player 2 begins their roll
8. First to the points you set, wins!

These rules will be reiterated for you in the code. 

## How to play
The first input will ask player one to `press r in order to roll your die`. Press enter after your input!
*IF YOU PRINT ANYTHING OTHER THAN R, YOUR TURN WILL BE PASSED!*

Once player one hits r
1. The program will print the 3 numbers you rolled 
2. your roll will then be evaluated to see if you have any die that can be RE-rolled
3. if you do, the program will ask if you'd like to `reroll the remaining dice?`
    1. if you would like to try for a higher number, you must press Y and enter
    2. if not, press N and enter
    3. You can keep rerolling until you tuple out or are satisfied with your rolls. 
4. The program will tell you your total score after your turn. 

## This will continue until one player reaches the desired score! 

Happy rolling! 